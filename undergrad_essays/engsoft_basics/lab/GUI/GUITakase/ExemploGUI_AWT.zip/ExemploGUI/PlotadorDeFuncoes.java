/*
 * Created on 15/03/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author fktakase
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import br.usp.pmr.laboratorio.FrameGrafico;

import java.awt.*;

public class PlotadorDeFuncoes {

	public static void main(String[] args) {
		FrameGrafico fg1 = new FrameGrafico("Janela", Color.white);
		fg1.setVisible(true);
	}
}
